class_name NoxAuthService
extends RefCounted

# Lightweight prototype auth contract. Production should replace this with HTTPS-backed auth.
var sessions: Dictionary = {}

func issue_session(account_id:String) -> String:
    var token := "%s-%s-%s" % [account_id,Time.get_ticks_msec(),randi()]
    sessions[token] = {"account_id":account_id,"issued":Time.get_unix_time_from_system()}
    return token

func valid(token:String) -> bool:
    return token != "" and sessions.has(token)

func account_id(token:String) -> String:
    return str(sessions.get(token,{}).get("account_id",""))

func revoke(token:String) -> void:
    sessions.erase(token)
