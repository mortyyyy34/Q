extends Node

func _ready() -> void:
    print("NOX STAR dedicated server booting — NOX GUARD enabled — ENet :9000")
