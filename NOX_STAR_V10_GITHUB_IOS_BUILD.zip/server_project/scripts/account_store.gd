class_name NoxAccountStore
extends RefCounted

const FILE_PATH := "user://nox_star_accounts.json"
var accounts: Dictionary = {}

func load_store() -> void:
    if not FileAccess.file_exists(FILE_PATH):
        accounts = {}
        return
    var f := FileAccess.open(FILE_PATH, FileAccess.READ)
    var parsed = JSON.parse_string(f.get_as_text())
    accounts = parsed if parsed is Dictionary else {}

func save_store() -> void:
    var f := FileAccess.open(FILE_PATH, FileAccess.WRITE)
    f.store_string(JSON.stringify(accounts))

func create_account(player_id:String, nick:String) -> Dictionary:
    var safe_id := player_id.strip_edges().left(48)
    if safe_id == "": return {"ok":false,"error":"invalid_id"}
    if accounts.has(safe_id): return {"ok":true,"account":accounts[safe_id]}
    var account := {"id":safe_id,"nick":nick.strip_edges().left(20),"trophies":0,"coins":500,"gems":0,"created":Time.get_unix_time_from_system()}
    accounts[safe_id] = account
    save_store()
    return {"ok":true,"account":account}

func get_account(player_id:String) -> Dictionary:
    return accounts.get(player_id, {})

func set_progress(player_id:String, trophies:int, coins:int, gems:int) -> void:
    if not accounts.has(player_id): return
    accounts[player_id]["trophies"] = max(0,trophies)
    accounts[player_id]["coins"] = max(0,coins)
    accounts[player_id]["gems"] = max(0,gems)
    save_store()
