class_name NoxModerationService
extends RefCounted

var muted: Dictionary = {}
var banned: Dictionary = {}

func ban(account_id:String, seconds:int, reason:String) -> void:
    banned[account_id] = {"until":Time.get_unix_time_from_system()+max(60,seconds),"reason":reason}

func is_banned(account_id:String) -> bool:
    if not banned.has(account_id): return false
    if float(banned[account_id]["until"]) <= Time.get_unix_time_from_system():
        banned.erase(account_id)
        return false
    return true

func mute(account_id:String, seconds:int) -> void:
    muted[account_id] = Time.get_unix_time_from_system()+max(30,seconds)
