class_name NoxReportService
extends RefCounted

const FILE_PATH := "user://nox_star_reports.jsonl"
const MAX_REASON := 120

func report(reporter_id:int, target_id:int, reason:String, match_id:int) -> bool:
    if reporter_id == target_id: return false
    var safe := reason.strip_edges().left(MAX_REASON)
    if safe == "": return false
    var f := FileAccess.open(FILE_PATH, FileAccess.READ_WRITE)
    if f == null: return false
    f.seek_end()
    f.store_line(JSON.stringify({"time":Time.get_unix_time_from_system(),"reporter":reporter_id,"target":target_id,"reason":safe,"match_id":match_id}))
    f.close()
    return true
