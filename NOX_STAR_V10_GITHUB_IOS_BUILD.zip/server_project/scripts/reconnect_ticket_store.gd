class_name NoxReconnectTicketStore
extends RefCounted

var tickets: Dictionary = {}
const TTL := 45.0

func issue(player_id:int, match_id:int, account_id:String) -> String:
    var ticket := "%s-%s-%s" % [player_id,match_id,randi()]
    tickets[ticket] = {"player_id":player_id,"match_id":match_id,"account_id":account_id,"expires":Time.get_ticks_msec() + int(TTL*1000.0)}
    return ticket

func consume(ticket:String, account_id:String) -> Dictionary:
    if not tickets.has(ticket): return {}
    var item:Dictionary = tickets[ticket]
    tickets.erase(ticket)
    if int(item.get("expires",0)) < Time.get_ticks_msec(): return {}
    if str(item.get("account_id","")) != account_id: return {}
    return item
