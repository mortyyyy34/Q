class_name NoxLeaderboardStore
extends RefCounted

const FILE_PATH := "user://nox_star_leaderboard.json"
var scores: Dictionary = {}

func load_store() -> void:
    if not FileAccess.file_exists(FILE_PATH):
        scores = {}
        return
    var f := FileAccess.open(FILE_PATH, FileAccess.READ)
    var parsed = JSON.parse_string(f.get_as_text())
    scores = parsed if parsed is Dictionary else {}

func save_store() -> void:
    var f := FileAccess.open(FILE_PATH, FileAccess.WRITE)
    f.store_string(JSON.stringify(scores))

func record(player_id:String, nick:String, trophies:int) -> void:
    scores[player_id] = {"id":player_id,"nick":nick,"trophies":max(0,trophies)}
    save_store()

func top(limit:int = 100) -> Array:
    var out:Array = []
    for value in scores.values(): out.append(value)
    out.sort_custom(func(a,b): return int(a.get("trophies",0)) > int(b.get("trophies",0)))
    return out.slice(0,min(limit,out.size()))
