class_name NoxPartyService
extends RefCounted

var parties: Dictionary = {}
var player_party: Dictionary = {}
var next_party_id := 1000

func create(owner_id:int) -> int:
    var pid := next_party_id
    next_party_id += 1
    parties[pid] = {"owner":owner_id,"members":[owner_id],"ready":{owner_id:false}}
    player_party[owner_id] = pid
    return pid

func invite(party_id:int, player_id:int) -> bool:
    if not parties.has(party_id) or player_party.has(player_id): return false
    var p:Dictionary = parties[party_id]
    if p["members"].size() >= 3: return false
    p["members"].append(player_id)
    p["ready"][player_id] = false
    player_party[player_id] = party_id
    return true

func set_ready(player_id:int,value:bool) -> bool:
    if not player_party.has(player_id): return false
    var pid:int = player_party[player_id]
    parties[pid]["ready"][player_id] = value
    return true

func all_ready(party_id:int) -> bool:
    if not parties.has(party_id): return false
    for value in parties[party_id]["ready"].values():
        if not bool(value): return false
    return true

func members(party_id:int) -> Array:
    return parties.get(party_id,{}).get("members",[])

func leave(player_id:int) -> void:
    if not player_party.has(player_id): return
    var pid:int = player_party[player_id]
    player_party.erase(player_id)
    if not parties.has(pid): return
    var p:Dictionary = parties[pid]
    p["members"].erase(player_id)
    p["ready"].erase(player_id)
    if p["members"].is_empty(): parties.erase(pid)
    elif int(p["owner"]) == player_id: p["owner"] = p["members"][0]
