class_name NoxSecurity
extends RefCounted

# Server-side anti-cheat. Never trusts client supplied HP, damage, score or result.
const MAX_MOVE_SPEED := 560.0
const MAX_STATE_GAP := 0.35
const MAX_STRIKES := 6
const WINDOW_SECONDS := 10.0

var records: Dictionary = {}

func _rec(id:int) -> Dictionary:
    if not records.has(id):
        records[id] = {"strikes":0,"window_start":Time.get_unix_time_from_system(),"shots":0,"last_pos":Vector2.ZERO,"last_state":Time.get_ticks_msec(),"muted_until":0}
    return records[id]

func check_state(id:int, old_pos:Vector2, new_pos:Vector2, elapsed:float) -> bool:
    var r := _rec(id)
    var now := Time.get_unix_time_from_system()
    if now - float(r["window_start"]) > WINDOW_SECONDS:
        r["window_start"] = now
        r["strikes"] = max(0, int(r["strikes"]) - 1)
    var dt := clamp(elapsed, 0.001, MAX_STATE_GAP)
    if old_pos != Vector2.ZERO and old_pos.distance_to(new_pos) > MAX_MOVE_SPEED * dt + 24.0:
        add_strike(id, "movement_speed")
        return false
    r["last_pos"] = new_pos
    r["last_state"] = Time.get_ticks_msec()
    return true

func check_shot(id:int, cooldown:float, requested_damage:float) -> bool:
    var r := _rec(id)
    if cooldown > 0.0:
        add_strike(id, "fire_rate")
        return false
    if requested_damage < 1.0 or requested_damage > 250.0:
        add_strike(id, "damage_value")
        return false
    r["shots"] = int(r["shots"]) + 1
    return true

func check_ability(id:int, ability:String, allowed:bool) -> bool:
    if not allowed:
        add_strike(id, "illegal_" + ability)
        return false
    return true

func add_strike(id:int, reason:String) -> void:
    var r := _rec(id)
    r["strikes"] = int(r["strikes"]) + 1
    print("NOX GUARD: player %d strike %d (%s)" % [id, int(r["strikes"]), reason])

func strikes(id:int) -> int:
    return int(_rec(id)["strikes"])

func should_kick(id:int) -> bool:
    return strikes(id) >= MAX_STRIKES

func clear(id:int) -> void:
    records.erase(id)
