# NOX STAR V8

NOX STAR is an online-only landscape mobile game project built with Godot 4.

## Important
The client does not fall back to local bots. A real server connection is required for login/lobby/matchmaking and battles.

## Dedicated server
The `server_project/` folder is a separate Godot project. Run it on a VPS/cloud host with UDP port 9000 open.

Set the client project setting:
`nox/server_host="YOUR_PUBLIC_SERVER_IP_OR_HOSTNAME"`

The current development default is `127.0.0.1`.

## Match sizes
- NEON RAID — 3v3 / 6 players
- CRYSTAL RUSH — 3v3 / 6 players
- SURVIVAL — 3v3 / 6 players
- DUO CLASH — 2v2 / 4 players
- VOID DUEL — 1v1 / 2 players
- SHOWDOWN SOLO — 10 individual players
- SHOWDOWN DUO — 10 players / 5 teams
- TRAINING — online server session for one player; no local bots

## Server authority
The V8 server owns combat state and validates:
- movement step limits
- hit detection
- damage
- deaths/respawns
- Super
- Boost Gem charges
- kills
- match score
- match timer
- match result

The client is responsible for presentation, input and rendering.

## Still required before public launch
- real account/authentication service
- persistent cloud player database
- production HTTPS API
- matchmaking queues with regional routing
- reconnect/resume tokens
- anti-cheat hardening and rate limits
- server deployment/monitoring
- App Store / Google Play packaging and certificates
- privacy policy / terms / moderation tooling
