# NOX STAR — iOS export package

This project is prepared for Godot 4 iOS export. A real signed .ipa cannot be produced without macOS/Xcode and Apple signing credentials.

## Build
1. Open the project in Godot 4.
2. Install the iOS export template matching the Godot version.
3. Project → Export → Add… → iOS.
4. Set the iOS bundle identifier to your own reverse-DNS ID, e.g. `com.yourstudio.noxstar`.
5. Export to an Xcode project on macOS.
6. Open the generated Xcode project, select your Apple Developer Team and signing profile, then Archive/Export or run on the device.

## Suggested settings
- Orientation: Landscape
- Minimum iOS version: choose one supported by your Godot/Xcode toolchain
- Game is online-only; no offline gameplay fallback
- Main scene: `res://scenes/Main.tscn`

Do not put your Apple certificates, provisioning profiles, private keys, or App Store credentials into this ZIP.
