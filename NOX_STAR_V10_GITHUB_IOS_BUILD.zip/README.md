# NOX STAR V10

Original online-only 3D/2D arena project built with Godot 4.

**Rule:** internet connection is required for account, lobby, matchmaking and every match.

## Modes
- NEON RAID — 3v3
- CRYSTAL RUSH — 3v3
- DUO CLASH — 2v2
- VOID DUEL — 1v1
- SHOWDOWN SOLO — 10 Noxers, last alive wins
- SHOWDOWN DUO — 10 Noxers / 5 teams
- SURVIVAL

## Systems retained
Noxers, attacks, Super, Boost Gem, cases, shop, quests, Trophy Road, match modifiers, server-authoritative combat and NOX GUARD.

## V10 additions
Party, invites, ready state, reconnect tickets, player reports, leaderboard storage, moderation primitives and auth/session contract.

See `BUILD_ROADMAP.md` and `ONLINE_SERVER.md` for production gates.
