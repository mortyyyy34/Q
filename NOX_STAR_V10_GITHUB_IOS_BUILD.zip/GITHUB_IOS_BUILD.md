# NOX STAR — GitHub iOS build

This package adds a GitHub Actions workflow that uses a GitHub-hosted macOS runner to export the Godot project to Xcode and build an **unsigned** iOS `.app`.

## Free route
For a **public GitHub repository**, standard GitHub-hosted runners are free and unlimited according to GitHub's current documentation. The workflow uses `macos-15`.

## From iPhone
1. Create a GitHub account.
2. Create a **new public repository**.
3. Upload the contents of this package to the repository (not the ZIP itself).
4. Open **Actions** → **Build NOX STAR iOS (unsigned)**.
5. Tap **Run workflow**.
6. Wait for the job to finish.
7. Open the workflow run → **Artifacts** → `NOX-STAR-iOS-unsigned`.
8. Download `NOX_STAR_UNSIGNED_APP.zip`.
9. Inside it is `NOX_STAR.app`.

Do not put `.p12`, private keys, passwords, or provisioning profiles in the repository.
