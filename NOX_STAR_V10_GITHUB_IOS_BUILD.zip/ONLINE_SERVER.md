# NOX STAR V10 Online Server

The project is online-only. Gameplay authority remains on the server.

## Network
- ENet transport prototype
- 20 Hz world snapshots
- server-side movement validation
- server-side fire/ability validation
- server-side match result

## Social
- Party: up to 3 members
- Invites
- Ready state
- Reconnect tickets
- Reports
- Leaderboard endpoint

## Security
- NOX GUARD strike system
- server-owned HP, damage, score and abilities
- movement/rate checks
- moderation primitives

This is still a development foundation. Public production requires real hosted infrastructure, persistent DB, TLS/auth gateway, monitoring, rate limiting and platform-specific account policies.
