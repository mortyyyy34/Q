# NOX STAR — V10 Build Roadmap

V10 keeps the cumulative V4–V9 systems and adds the social/operations layer needed before a public online alpha.

## Included
- Online-only gate
- Dedicated ENet server foundation
- Server-authoritative combat foundation
- NOX GUARD anti-cheat foundation
- 3v3 / 2v2 / 1v1
- Solo Showdown: 10 players
- Duo Showdown: 10 players / 5 teams
- Trophy Road
- Noxers / cases / quests / shop / modifiers
- Party creation and up to 3 members
- Party invites
- Ready state
- Reconnect ticket service
- Player reports
- Leaderboard storage
- Moderation ban/mute primitives
- Session token contract

## Next production gates
1. Deploy dedicated servers with TLS-backed account/auth service.
2. Replace prototype file stores with PostgreSQL/Redis.
3. Add authoritative lag compensation and snapshot interpolation.
4. Add crash/error telemetry and server metrics.
5. Add App Store/Google Play builds and real-device QA.
