class_name NoxSocialService
extends RefCounted

var friends: Array[String] = []
var pending_invites: Array[String] = []
var party_id: int = 0
var party_owner: bool = false
var ready := false
var online_friends: Array[String] = []

func add_friend(player_id:String) -> void:
    if player_id != "" and not friends.has(player_id): friends.append(player_id)

func remove_friend(player_id:String) -> void:
    friends.erase(player_id)
    online_friends.erase(player_id)

func receive_invite(party:String) -> void:
    if party != "" and not pending_invites.has(party): pending_invites.append(party)

func clear_invite(party:String) -> void:
    pending_invites.erase(party)

func set_ready(value:bool) -> void:
    ready = value
