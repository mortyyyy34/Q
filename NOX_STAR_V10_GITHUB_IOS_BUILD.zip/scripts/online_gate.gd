class_name NoxOnlineGate
extends RefCounted

# Online-only rule: gameplay must never start while disconnected.
func can_enter_lobby(connected:bool) -> bool:
    return connected

func can_enter_battle(connected:bool, match_active:bool) -> bool:
    return connected and match_active

func disconnected_message() -> String:
    return "NO CONNECTION — NOX STAR REQUIRES INTERNET"
