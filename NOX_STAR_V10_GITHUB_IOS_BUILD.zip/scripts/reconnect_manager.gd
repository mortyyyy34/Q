class_name NoxReconnectManager
extends RefCounted

const MAX_ATTEMPTS := 5
var attempts := 0
var backoff := 1.0
var last_match_id := ""
var last_host := ""

func remember(host:String, match_id:String) -> void:
    last_host = host
    last_match_id = match_id
    attempts = 0
    backoff = 1.0

func next_delay() -> float:
    attempts += 1
    var d := min(10.0, backoff)
    backoff = min(10.0, backoff * 2.0)
    return d

func can_retry() -> bool:
    return attempts < MAX_ATTEMPTS

func clear() -> void:
    attempts = 0
    backoff = 1.0
    last_match_id = ""
