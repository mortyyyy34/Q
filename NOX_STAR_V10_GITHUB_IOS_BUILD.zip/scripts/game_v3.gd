
extends Node2D

const W := 1600.0
const H := 900.0
const MATCH_TIME := 120.0
const MAX_HP := 1000.0
const FIRE_COOLDOWN := 0.42
const SUPER_MAX := 100.0
const BOOST_MAX := 3

var screen := "lobby"
var mode := "NEON RAID"
var loading := 0.0
var match_time := MATCH_TIME
var score_blue := 0
var score_red := 0
var player := Vector2(390, 470)
var hp := MAX_HP
var enemy_spawn := Vector2(1210, 390)
var player_spawn := Vector2(390, 470)
var super_charge := 0.0
var boost_charges := 1
var trophies := 0
var coins := 500
var gems := 0
var chest := 30
var fire_cd := 0.0
var hit_flash := 0.0
var message := ""
var message_time := 0.0
var respawn_time := 0.0
var dead := false
var joystick := Vector2.ZERO
var aim := Vector2(1, 0)
var dragging_move := false
var dragging_aim := false
var touch_move_id := -1
var touch_aim_id := -1
var projectiles: Array = []
var enemies: Array = []
var allies: Array = []
var crystals: Array = []
var particles: Array = []
var font: Font = ThemeDB.fallback_font
var tex_kai: Texture2D
var tex_nyx: Texture2D
var tex_volt: Texture2D
var tex_neon: Texture2D
var tex_void: Texture2D
var attack_sfx: AudioStream
var hit_sfx: AudioStream
var super_sfx: AudioStream
var victory_sfx: AudioStream

func _ready() -> void:
    tex_kai = load("res://assets/characters_png/kai_sheet.png")
    tex_nyx = load("res://assets/characters_png/nyx_sheet.png")
    tex_volt = load("res://assets/characters_png/volt_sheet.png")
    tex_neon = load("res://assets/maps_png/neon_raid.png")
    tex_void = load("res://assets/maps_png/void_duel.png")
    attack_sfx = load("res://assets/audio/attack.wav")
    hit_sfx = load("res://assets/audio/hit.wav")
    super_sfx = load("res://assets/audio/super.wav")
    trophies = int(ProjectSettings.get_setting("nox/trophies", 0))
    coins = int(ProjectSettings.get_setting("nox/coins", 500))
    queue_redraw()

func _process(delta: float) -> void:
    if message_time > 0:
        message_time -= delta
    if hit_flash > 0:
        hit_flash -= delta
    if screen == "loading":
        loading += delta
        if loading >= 1.8:
            screen = "battle"
            begin_match()
    elif screen == "battle":
        update_battle(delta)
    queue_redraw()

func _input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed:
        if event.keycode == KEY_ESCAPE:
            screen = "lobby"
        elif event.keycode == KEY_SPACE:
            fire()
        elif event.keycode == KEY_Q:
            use_super()
        elif event.keycode == KEY_E:
            use_boost()

    if event is InputEventScreenTouch:
        if event.pressed:
            handle_touch_down(event.index, event.position)
        else:
            handle_touch_up(event.index)

    if event is InputEventScreenDrag:
        handle_touch_drag(event.index, event.position)

func handle_touch_down(id: int, p: Vector2) -> void:
    if screen == "lobby":
        if Rect2(650, 700, 300, 90).has_point(p):
            screen = "modes"
        elif Rect2(30, 760, 260, 90).has_point(p):
            screen = "road"
    elif screen == "modes":
        if Rect2(180, 300, 360, 250).has_point(p):
            mode = "NEON RAID"
            screen = "loading"
            loading = 0
        elif Rect2(620, 300, 360, 250).has_point(p):
            mode = "VOID DUEL"
            screen = "loading"
            loading = 0
        elif Rect2(1060, 300, 360, 250).has_point(p):
            mode = "TRAINING"
            screen = "loading"
            loading = 0
    elif screen == "road":
        if Rect2(30, 25, 180, 65).has_point(p):
            screen = "lobby"
    elif screen == "result":
        if Rect2(620, 690, 360, 90).has_point(p):
            screen = "lobby"
    elif screen == "battle":
        if p.x < W * 0.42 and p.y > H * 0.50:
            dragging_move = true
            touch_move_id = id
            joystick = (p - Vector2(160, 690)) / 105.0
            joystick = joystick.limit_length(1.0)
        elif p.x > W * 0.58 and p.y > H * 0.48:
            dragging_aim = true
            touch_aim_id = id
            var a := p - player
            if a.length() > 10:
                aim = a.normalized()
        elif Rect2(W - 250, H - 190, 150, 150).has_point(p):
            fire()
        elif Rect2(W - 420, H - 165, 120, 120).has_point(p):
            use_super()
        elif Rect2(W - 420, H - 315, 90, 90).has_point(p):
            use_boost()

func handle_touch_drag(id: int, p: Vector2) -> void:
    if screen != "battle":
        return
    if id == touch_move_id:
        joystick = (p - Vector2(160, 690)) / 105.0
        joystick = joystick.limit_length(1.0)
    elif id == touch_aim_id:
        var a := p - player
        if a.length() > 10:
            aim = a.normalized()

func handle_touch_up(id: int) -> void:
    if id == touch_move_id:
        dragging_move = false
        touch_move_id = -1
        joystick = Vector2.ZERO
    if id == touch_aim_id:
        dragging_aim = false
        touch_aim_id = -1

func begin_match() -> void:
    match_time = MATCH_TIME
    score_blue = 0
    score_red = 0
    hp = MAX_HP
    super_charge = 0
    boost_charges = 1
    player = player_spawn
    dead = false
    projectiles.clear()
    enemies.clear()
    allies.clear()
    crystals.clear()
    particles.clear()
    for p in [Vector2(790,420), Vector2(820,470), Vector2(780,520), Vector2(850,500), Vector2(760,465)]:
        crystals.append({"p": p, "taken": false, "pulse": randf() * 6.0})
    # Two AI enemies and two allies for the 3v3 feeling.
    enemies = [
        {"p": Vector2(1180,350), "hp": 900.0, "max": 900.0, "cool": 0.0, "respawn": 0.0, "dead": false, "name": "NYX"},
        {"p": Vector2(1240,560), "hp": 900.0, "max": 900.0, "cool": 0.5, "respawn": 0.0, "dead": false, "name": "VOLT"}
    ]
    allies = [
        {"p": Vector2(300,350), "hp": 900.0, "max": 900.0, "cool": 0.0, "respawn": 0.0, "dead": false, "name": "VOLT"},
        {"p": Vector2(300,590), "hp": 900.0, "max": 900.0, "cool": 0.4, "respawn": 0.0, "dead": false, "name": "NYX"}
    ]
    show_message(mode)

func show_message(s: String) -> void:
    message = s
    message_time = 1.2

func update_battle(delta: float) -> void:
    match_time -= delta
    fire_cd = max(0.0, fire_cd - delta)
    for p in particles.duplicate():
        p["life"] -= delta
        p["p"] += p["v"] * delta
        if p["life"] <= 0:
            particles.erase(p)
    if dead:
        respawn_time -= delta
        if respawn_time <= 0:
            dead = false
            hp = MAX_HP
            player = player_spawn
        return

    var move_vec := joystick
    if Input.is_key_pressed(KEY_A): move_vec.x -= 1
    if Input.is_key_pressed(KEY_D): move_vec.x += 1
    if Input.is_key_pressed(KEY_W): move_vec.y -= 1
    if Input.is_key_pressed(KEY_S): move_vec.y += 1
    move_vec = move_vec.limit_length(1.0)
    if move_vec.length() > 0.05:
        player += move_vec * 360.0 * delta
        player = clamp_to_arena(player)

    for c in crystals:
        if not c["taken"] and player.distance_to(c["p"]) < 55:
            c["taken"] = true
            score_blue += 1
            super_charge = min(SUPER_MAX, super_charge + 8)
            spawn_fx(c["p"], Color("#65eaff"), 12)

    ai_team(enemies, true, delta)
    ai_team(allies, false, delta)
    update_projectiles(delta)

    if mode == "NEON RAID" and score_blue >= 10:
        end_match(true)
    elif match_time <= 0:
        end_match(score_blue >= score_red)

func ai_team(team: Array, hostile: bool, delta: float) -> void:
    for unit in team:
        if unit["dead"]:
            unit["respawn"] -= delta
            if unit["respawn"] <= 0:
                unit["dead"] = false
                unit["hp"] = unit["max"]
                unit["p"] = Vector2(1180, 350) if hostile else Vector2(300, 450)
            continue
        var target := player
        if not hostile:
            if enemies.size() > 0 and not enemies[0]["dead"]:
                target = enemies[0]["p"]
            elif enemies.size() > 1:
                target = enemies[1]["p"]
        var d: Vector2 = target - unit["p"]
        if d.length() > 240:
            unit["p"] += d.normalized() * 110.0 * delta
        elif d.length() < 130:
            unit["p"] -= d.normalized() * 55.0 * delta
        unit["p"] = clamp_to_arena(unit["p"])
        unit["cool"] -= delta
        if unit["cool"] <= 0 and d.length() < 720:
            unit["cool"] = 1.05 if hostile else 1.25
            projectiles.append({
                "p": unit["p"],
                "v": d.normalized() * 560.0,
                "team": "red" if hostile else "blue",
                "damage": 90.0,
                "life": 1.7,
                "owner": unit
            })

func update_projectiles(delta: float) -> void:
    for b in projectiles.duplicate():
        b["p"] += b["v"] * delta
        b["life"] -= delta
        var remove := b["life"] <= 0 or b["p"].x < 20 or b["p"].x > W-20 or b["p"].y < 100 or b["p"].y > H-30
        if not remove:
            if b["team"] == "red" and not dead and b["p"].distance_to(player) < 42:
                hp -= b["damage"]
                super_charge = min(SUPER_MAX, super_charge + 10)
                spawn_fx(player, Color("#ff5f83"), 14)
                remove = true
                if hp <= 0:
                    die_player()
            elif b["team"] == "blue":
                for e in enemies:
                    if not e["dead"] and b["p"].distance_to(e["p"]) < 45:
                        e["hp"] -= b["damage"]
                        super_charge = min(SUPER_MAX, super_charge + 16)
                        spawn_fx(e["p"], Color("#ffe16b"), 12)
                        remove = true
                        if e["hp"] <= 0:
                            e["dead"] = true
                            e["respawn"] = 4.0
                            score_blue += 1
                        break
        if remove:
            projectiles.erase(b)

func fire() -> void:
    if screen != "battle" or dead or fire_cd > 0:
        return
    fire_cd = FIRE_COOLDOWN
    var direction := aim
    if direction.length() < 0.1:
        direction = Vector2(1,0)
    projectiles.append({
        "p": player + direction * 55,
        "v": direction * 900,
        "team": "blue",
        "damage": 140.0,
        "life": 1.0,
        "owner": null
    })
    spawn_fx(player + direction * 55, Color("#ffe16b"), 5)

func use_super() -> void:
    if screen != "battle" or dead or super_charge < SUPER_MAX:
        show_message("SUPER NOT READY")
        return
    super_charge = 0
    spawn_fx(player, Color("#8060f4"), 70)
    for e in enemies:
        if not e["dead"] and e["p"].distance_to(player) < 260:
            e["hp"] -= 360
            spawn_fx(e["p"], Color("#65eaff"), 20)
            if e["hp"] <= 0:
                e["dead"] = true
                e["respawn"] = 4.0
                score_blue += 2
    player += aim * 90
    player = clamp_to_arena(player)
    show_message("NOVA BURST!")

func use_boost() -> void:
    if screen != "battle" or boost_charges <= 0:
        show_message("NO BOOST")
        return
    boost_charges -= 1
    hp = min(MAX_HP, hp + 280)
    super_charge = min(SUPER_MAX, super_charge + 25)
    spawn_fx(player, Color("#41dfd0"), 32)
    show_message("BOOST +280 HP")

func die_player() -> void:
    dead = true
    respawn_time = 3.5
    score_red += 1
    spawn_fx(player, Color("#ff5f83"), 45)
    show_message("RESPAWNING...")

func end_match(win: bool) -> void:
    if screen != "battle":
        return
    screen = "result"
    if win:
        trophies += 8
        coins += 35
        chest = min(100, chest + 15)
        show_message("VICTORY")
    else:
        trophies = max(0, trophies - 2)
        coins += 10
        chest = min(100, chest + 4)
        show_message("DEFEAT")
    ProjectSettings.set_setting("nox/trophies", trophies)
    ProjectSettings.set_setting("nox/coins", coins)

func clamp_to_arena(p: Vector2) -> Vector2:
    return Vector2(clamp(p.x, 70.0, W-70.0), clamp(p.y, 135.0, H-80.0))

func spawn_fx(p: Vector2, color: Color, count: int) -> void:
    for i in range(count):
        var a := randf() * TAU
        var speed := randf_range(50, 230)
        particles.append({"p": p, "v": Vector2(cos(a),sin(a))*speed, "life": randf_range(.25,.65), "c": color})

func _draw() -> void:
    if screen == "lobby":
        draw_lobby()
    elif screen == "modes":
        draw_modes()
    elif screen == "road":
        draw_road()
    elif screen == "loading":
        draw_loading()
    elif screen == "battle":
        draw_battle()
    elif screen == "result":
        draw_result()

func draw_lobby() -> void:
    draw_rect(Rect2(0,0,W,H), Color("#080d20"))
    if tex_neon:
        draw_texture_rect(tex_neon, Rect2(0,0,W,H), false)
    draw_rect(Rect2(0,0,W,H), Color("#07102dcc"))
    top_bar()
    panel(Rect2(45,160,310,210), "NEON RAID", "3v3 • CRYSTAL CONTROL")
    panel(Rect2(1245,160,310,210), "VOID DUEL", "1v1 • LAST STAR")
    draw_brawler(tex_kai, player, 0, 1.0)
    text("KAI • STAR RUNNER", Vector2(610,590), 34)
    text("RANGED • BALANCED • NOVA BURST", Vector2(620,625), 18, Color("#b6c4e8"))
    button(Rect2(650,700,300,90), "PLAY", Color("#ffb72e"))
    panel(Rect2(45,640,310,160), "STAR ROAD", "🏆 %d trophies\n🎁 %d/100 to Star Case" % [trophies, chest])
    panel(Rect2(1245,640,310,160), "EVENTS", "NEON RAID\nVOID DUEL\nTRAINING")

func draw_modes() -> void:
    draw_rect(Rect2(0,0,W,H),Color("#0a1024"))
    top_bar()
    text("SELECT EVENT",Vector2(70,150),48)
    panel(Rect2(180,300,360,250),"NEON RAID","3v3\nCollect crystals\n🏆 +8")
    panel(Rect2(620,300,360,250),"VOID DUEL","1v1\nDefeat the rival\n🏆 +8")
    panel(Rect2(1060,300,360,250),"TRAINING","Practice\nmovement + aim")
    text("TAP A MODE",Vector2(690,650),20,Color("#aab8df"))

func draw_road() -> void:
    draw_rect(Rect2(0,0,W,H),Color("#091025"))
    top_bar()
    button(Rect2(30,25,180,65),"← BACK",Color("#182342"))
    text("TROPHY ROAD",Vector2(80,165),50)
    for i in range(6):
        var x=140+i*260
        var got=trophies>=i*100
        draw_circle(Vector2(x,410),54,Color("#ffd04a") if got else Color("#283554"))
        text(str(i*100),Vector2(x-25,490),20)
        if i<5:
            draw_line(Vector2(x+55,410),Vector2(x+205,410),Color("#405684"),8)
    text("STAR CASE",Vector2(670,620),32)
    text("%d / 100" % chest,Vector2(720,670),28,Color("#65eaff"))
    text("Cases can contain Boost Gems and upgrade rewards.",Vector2(510,730),20,Color("#aeb9db"))

func draw_loading() -> void:
    draw_rect(Rect2(0,0,W,H),Color("#070b18"))
    text("NOX STAR",Vector2(650,330),64)
    text("LOADING %s" % mode,Vector2(620,420),25,Color("#b6c4e8"))
    draw_rect(Rect2(450,520,700,28),Color("#18233e"))
    draw_rect(Rect2(450,520,700*min(1.0,loading/1.8),28),Color("#55dfff"))
    text("Preparing arena • syncing fighters • loading effects",Vector2(510,590),18,Color("#8fa3cf"))

func draw_battle() -> void:
    var map_tex := tex_neon
    if mode == "VOID DUEL":
        map_tex = tex_void
    if map_tex:
        draw_texture_rect(map_tex,Rect2(0,0,W,H),false)
    draw_rect(Rect2(0,0,W,H),Color("#06101a55"))
    top_bar()
    # HUD
    health_bar(Vector2(35,105),hp,MAX_HP,"KAI",Color("#55e58b"))
    var alive_enemies := 0
    for e in enemies:
        if not e["dead"]: alive_enemies += 1
    text("ENEMIES %d" % alive_enemies,Vector2(1350,145),18,Color("#ff91a9"))
    text("%02d:%02d" % [int(match_time)/60,int(match_time)%60],Vector2(750,118),30)
    text("%d  —  %d" % [score_blue,score_red],Vector2(745,155),24,Color("#ffe16b"))
    # crystals
    for c in crystals:
        if not c["taken"]:
            var q:Vector2=c["p"]
            var pulse=4.0+sin(Time.get_ticks_msec()/180.0+c["pulse"])*5.0
            var pts=PackedVector2Array([q+Vector2(0,-24-pulse),q+Vector2(24,0),q+Vector2(0,24+pulse),q+Vector2(-24,0)])
            draw_colored_polygon(pts,Color("#65eaff"))
            draw_polyline(pts,Color.WHITE,4)
    # units
    if not dead:
        var frame := int(Time.get_ticks_msec()/110)%8
        draw_brawler_frame(tex_kai,player,frame,.72)
    for e in enemies:
        if not e["dead"]:
            draw_brawler_frame(tex_nyx,e["p"],int(Time.get_ticks_msec()/140)%8,.60)
            small_hp(e["p"]+Vector2(-50,-95),e["hp"],e["max"],Color("#ff5f83"))
    for a in allies:
        if not a["dead"]:
            draw_brawler_frame(tex_volt,a["p"],int(Time.get_ticks_msec()/150)%8,.52)
            small_hp(a["p"]+Vector2(-45,-85),a["hp"],a["max"],Color("#55e58b"))
    # projectiles
    for b in projectiles:
        draw_circle(b["p"],9,Color("#ffe16b") if b["team"]=="blue" else Color("#ff668a"))
    for p in particles:
        draw_circle(p["p"],max(2.0,9.0*p["life"]),p["c"])
    controls()

func controls() -> void:
    draw_circle(Vector2(160,690),105,Color("#071329b8"))
    draw_circle(Vector2(160+joystick.x*42,690+joystick.y*42),34,Color("#a7b9d4cc"))
    draw_circle(Vector2(W-125,H-120),82,Color("#ff7b3b"))
    text("ATTACK",Vector2(W-176,H-111),20,Color("#241000"))
    var sc=super_charge/SUPER_MAX
    draw_circle(Vector2(W-360,H-105),58,Color("#8060f4") if sc>=1 else Color("#4a3f76"))
    text("SUPER",Vector2(W-399,H-99),16)
    draw_arc(Vector2(W-360,H-105),68,-PI/2,-PI/2+TAU*sc,false,6,Color("#d8d0ff"))
    draw_circle(Vector2(W-375,H-270),45,Color("#41dfd0") if boost_charges>0 else Color("#285e60"))
    text("BOOST",Vector2(W-401,H-265),13,Color("#062326"))
    if dead:
        draw_rect(Rect2(0,0,W,H),Color("#05071399"))
        text("RESPAWNING %0.1f" % respawn_time,Vector2(675,430),34,Color("#ff91a9"))
    if message_time>0:
        text(message,Vector2(650,195),28,Color("#ffe16b"))

func draw_result() -> void:
    draw_rect(Rect2(0,0,W,H),Color("#091025"))
    top_bar()
    var win := score_blue >= score_red
    text("VICTORY" if win else "DEFEAT",Vector2(625,300),72,Color("#ffd04a") if win else Color("#ff6688"))
    text("🏆",Vector2(750,420),80)
    text("+8 TROPHIES • +35 COINS" if win else "-2 TROPHIES • +10 COINS",Vector2(610,540),25)
    text("SCORE  %d — %d" % [score_blue,score_red],Vector2(705,590),25)
    button(Rect2(620,690,360,90),"CONTINUE",Color("#ffb72e"))

func top_bar() -> void:
    draw_rect(Rect2(0,0,W,92),Color("#060a18e8"))
    text("NOX STAR",Vector2(35,59),38)
    text("🏆 %d     🪙 %d     💎 %d" % [trophies,coins,gems],Vector2(1120,56),22)

func panel(r:Rect2,title:String,sub:String) -> void:
    draw_rect(r,Color("#111b39e8"))
    draw_rect(r,Color("#41598d"),false,4)
    text(title,r.position+Vector2(18,48),28)
    text(sub,r.position+Vector2(18,84),17,Color("#b4c1e3"))

func button(r:Rect2,label:String,c:Color) -> void:
    draw_rect(r,c)
    draw_rect(r,Color("#ffe69b"),false,4)
    text(label,r.position+Vector2(0,55),28,Color("#241400"),r.size.x,HORIZONTAL_ALIGNMENT_CENTER)

func text(s:String,p:Vector2,size:int,c:=Color.WHITE,width:float=-1,align:=HORIZONTAL_ALIGNMENT_LEFT) -> void:
    draw_string(font,p,s,align,width,size,c)

func health_bar(p:Vector2,h:float,m:float,n:String,c:Color) -> void:
    text(n,p,20)
    draw_rect(Rect2(p+Vector2(0,25),Vector2(280,20)),Color("#111827"))
    draw_rect(Rect2(p+Vector2(3,28),Vector2(274*clamp(h/m,0,1),14)),c)

func small_hp(p:Vector2,h:float,m:float,c:Color) -> void:
    draw_rect(Rect2(p,Vector2(100,9)),Color("#111827"))
    draw_rect(Rect2(p+Vector2(2,2),Vector2(96*clamp(h/m,0,1),5)),c)

func draw_brawler(tex:Texture2D,p:Vector2,scale:float) -> void:
    draw_brawler_frame(tex,p,int(Time.get_ticks_msec()/120)%8,scale)

func draw_brawler_frame(tex:Texture2D,p:Vector2,frame:int,scale:float) -> void:
    if tex == null: return
    var src := Rect2((frame%8)*512,0,512,512)
    var dst := Rect2(p-Vector2(190,190)*scale,Vector2(380,380)*scale)
    draw_texture_rect_region(tex,dst,src)

