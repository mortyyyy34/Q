class_name NoxNetworkCore
extends Node

signal status_changed(text)
signal roster_changed(players)
signal match_ready(mode, players)
signal world_updated(players)
signal remote_shot_received(player_id, pos, direction, damage)
signal match_ended(reason)

const DEFAULT_PORT := 9000
const MAX_PLAYERS := 100
const MAX_HP := 1000.0
const TICK_RATE := 20.0
const MATCH_LENGTH := 120.0

var peer := ENetMultiplayerPeer.new()
var connected := false
var server_mode := false
var online_mode := true
var mode := "NEON RAID"
var player_name := "Nox"
var players: Array = []
var queued_mode := ""
var match_active := false
var last_status := "OFFLINE"
var _tick_accum := 0.0
var _matches: Dictionary = {}

func _ready() -> void:
    server_mode = bool(ProjectSettings.get_setting("nox/server_mode", false))
    multiplayer.peer_connected.connect(_on_peer_connected)
    multiplayer.peer_disconnected.connect(_on_peer_disconnected)
    multiplayer.connected_to_server.connect(_on_connected)
    multiplayer.connection_failed.connect(_on_failed)
    multiplayer.server_disconnected.connect(_on_server_disconnected)
    if server_mode:
        var err := peer.create_server(DEFAULT_PORT, MAX_PLAYERS)
        if err == OK:
            multiplayer.multiplayer_peer = peer
            connected = true
            _set_status("SERVER ONLINE :%d" % DEFAULT_PORT)
        else:
            _set_status("SERVER ERROR " + str(err))

func _process(delta: float) -> void:
    if server_mode:
        _tick_accum += delta
        if _tick_accum >= 1.0 / TICK_RATE:
            _tick_accum = 0.0
            _server_tick(1.0 / TICK_RATE)

func connect_online(host:String, port:int = DEFAULT_PORT, wanted_mode:String = "NEON RAID", nick:String = "Nox") -> void:
    if server_mode: return
    mode = wanted_mode
    player_name = nick
    queued_mode = wanted_mode
    online_mode = true
    _set_status("CONNECTING TO " + host)
    if multiplayer.multiplayer_peer != null:
        multiplayer.multiplayer_peer = null
    peer = ENetMultiplayerPeer.new()
    var err := peer.create_client(host, port)
    if err != OK:
        _set_status("CONNECTION ERROR")
        return
    multiplayer.multiplayer_peer = peer

func queue_for_mode(wanted_mode:String) -> void:
    mode = wanted_mode
    queued_mode = wanted_mode
    if connected and not server_mode:
        server_queue.rpc_id(1, player_name, mode)
        _set_status("SEARCHING • " + mode)
    elif not server_mode:
        _set_status("NO INTERNET SERVER")

func send_player_state(pos:Vector2,hp:float,super_charge:float,dead:bool) -> void:
    # hp/super/dead are retained in the signature for compatibility, but the server owns them.
    if connected and not server_mode and match_active:
        client_state.rpc_id(1,pos)

func send_shot(pos:Vector2,direction:Vector2,damage:float) -> void:
    if connected and not server_mode and match_active:
        player_shot.rpc_id(1,pos,direction.normalized(),damage)

func send_super() -> void:
    if connected and not server_mode and match_active:
        player_super.rpc_id(1)

func send_boost() -> void:
    if connected and not server_mode and match_active:
        player_boost.rpc_id(1)

func leave_match() -> void:
    if connected and not server_mode:
        leave_match_rpc.rpc_id(1)
    match_active = false

func _on_connected() -> void:
    connected = true
    _set_status("ONLINE")
    register_player.rpc_id(1,player_name)
    if queued_mode != "": queue_for_mode(queued_mode)

func _on_failed() -> void:
    connected = false
    match_active = false
    _set_status("CONNECTION FAILED — INTERNET REQUIRED")

func _on_server_disconnected() -> void:
    connected = false
    match_active = false
    _set_status("SERVER OFFLINE — RETRY")

func _on_peer_connected(id:int) -> void:
    if server_mode:
        players.append(_new_player(id))
        _send_roster()

func _on_peer_disconnected(id:int) -> void:
    if server_mode:
        var removed_match := 0
        for p in players.duplicate():
            if int(p["id"]) == id:
                removed_match = int(p.get("match_id",0))
                players.erase(p)
        if removed_match != 0:
            _broadcast_match(removed_match)
        _send_roster()

func _new_player(id:int) -> Dictionary:
    return {"id":id,"name":"Nox-"+str(id),"mode":"","ready":false,"match_id":0,"team":-1,"pos":Vector2.ZERO,"hp":MAX_HP,"super":0.0,"dead":false,"boosts":1,"kills":0,"deaths":0,"last_pos":Vector2.ZERO,"last_state_ms":Time.get_ticks_msec(),"respawn":0.0,"fire_cd":0.0}

func _set_status(s:String) -> void:
    last_status = s
    status_changed.emit(s)

func _send_roster() -> void:
    if server_mode:
        roster.rpc(players)

@rpc("any_peer","reliable")
func register_player(nick:String) -> void:
    if not server_mode:return
    var id := multiplayer.get_remote_sender_id()
    for p in players:
        if int(p["id"]) == id:
            p["name"] = nick.strip_edges().left(20) if nick.strip_edges() != "" else "Nox"
    _send_roster()

@rpc("any_peer","reliable")
func server_queue(nick:String,wanted_mode:String) -> void:
    if not server_mode:return
    var id := multiplayer.get_remote_sender_id()
    for p in players:
        if int(p["id"]) == id:
            p["name"] = nick.strip_edges().left(20)
            p["mode"] = wanted_mode
            p["ready"] = true
    _try_match(wanted_mode)
    _send_roster()

func _required_players(wanted_mode:String) -> int:
    match wanted_mode:
        "SHOWDOWN SOLO", "SHOWDOWN DUO": return 10
        "NEON RAID", "CRYSTAL RUSH", "SURVIVAL": return 6
        "DUO CLASH": return 4
        "VOID DUEL": return 2
        "TRAINING": return 1
    return 6

func _try_match(wanted_mode:String) -> void:
    var needed := _required_players(wanted_mode)
    var queue:Array = []
    for p in players:
        if p["mode"] == wanted_mode and p["ready"] and int(p["match_id"]) == 0:
            queue.append(p)
    if queue.size() < needed: return
    var chosen:Array = queue.slice(0,needed)
    var match_id := Time.get_ticks_msec()
    var state := {"mode":wanted_mode,"time":MATCH_LENGTH,"blue":0,"red":0,"started":true}
    _matches[match_id] = state
    var idx := 0
    for p in chosen:
        p["ready"] = false
        p["match_id"] = match_id
        p["hp"] = MAX_HP
        p["super"] = 0.0
        p["dead"] = false
        p["boosts"] = 1
        p["kills"] = 0
        p["deaths"] = 0
        if wanted_mode == "SHOWDOWN SOLO": p["team"] = idx
        elif wanted_mode == "SHOWDOWN DUO": p["team"] = int(idx / 2)
        elif wanted_mode in ["NEON RAID","CRYSTAL RUSH","SURVIVAL"]: p["team"] = 0 if idx < 3 else 1
        elif wanted_mode == "DUO CLASH": p["team"] = 0 if idx < 2 else 1
        else: p["team"] = 0 if idx == 0 else 1
        idx += 1
    match_found.rpc(wanted_mode,chosen)
    _broadcast_match(match_id)

func _players_in_match(match_id:int) -> Array:
    var result:Array = []
    for p in players:
        if int(p.get("match_id",0)) == match_id: result.append(p)
    return result

func _broadcast_match(match_id:int) -> void:
    if match_id == 0: return
    var state := _players_in_match(match_id)
    if state.size() > 0:
        var m:Dictionary=_matches.get(match_id,{})
        var remaining:=float(m.get("time",MATCH_LENGTH))
        var blue:=int(m.get("blue",0))
        var red:=int(m.get("red",0))
        for p in state:
            p["match_time"]=remaining
            p["score_blue"]=blue
            p["score_red"]=red
        world_state.rpc(state)

@rpc("any_peer","unreliable")
func client_state(pos:Vector2) -> void:
    if not server_mode:return
    var id := multiplayer.get_remote_sender_id()
    for p in players:
        if int(p["id"]) != id: continue
        var mid := int(p["match_id"])
        if mid == 0 or bool(p["dead"]): return
        var now := Time.get_ticks_msec()
        var dt := clamp(float(now-int(p["last_state_ms"])) / 1000.0,0.01,0.25)
        var old:Vector2 = p["pos"]
        var requested := pos
        var max_step := 500.0 * dt + 18.0
        if old == Vector2.ZERO:
            p["pos"] = requested
        elif old.distance_to(requested) <= max_step:
            p["pos"] = requested
        else:
            p["pos"] = old + (requested-old).limit_length(max_step)
        p["last_pos"] = old
        p["last_state_ms"] = now
        _broadcast_match(mid)
        return

@rpc("any_peer","unreliable")
func player_shot(pos:Vector2,direction:Vector2,damage:float) -> void:
    if not server_mode:return
    var shooter_id := multiplayer.get_remote_sender_id()
    var shooter = _find_player(shooter_id)
    if shooter == null or int(shooter["match_id"]) == 0 or bool(shooter["dead"]): return
    if float(shooter.get("fire_cd",0.0)) > 0.0: return
    shooter["fire_cd"] = 0.42
    var mid := int(shooter["match_id"])
    var dir := direction.normalized()
    if dir.length() < 0.5: return
    var start:Vector2 = shooter["pos"]
    var shot_pos := start + dir * 55.0
    var safe_damage := clamp(damage,80.0,180.0)
    remote_shot.rpc(shot_pos,dir,safe_damage,shooter_id,mid)
    var best = null
    var best_dist := 999999.0
    for target in _players_in_match(mid):
        if int(target["id"]) == shooter_id or bool(target["dead"]): continue
        if not _are_enemies(shooter,target): continue
        var to_target:Vector2 = target["pos"] - start
        var forward := to_target.dot(dir)
        if forward < 0.0 or forward > 900.0: continue
        var closest := start + dir * forward
        var lateral := target["pos"].distance_to(closest)
        if lateral <= 58.0 and forward < best_dist:
            best = target
            best_dist = forward
    if best != null:
        best["hp"] = max(0.0,float(best["hp"]) - safe_damage)
        shooter["super"] = min(100.0,float(shooter["super"]) + 14.0)
        if float(best["hp"]) <= 0.0:
            _kill_player(shooter,best)
    _broadcast_match(mid)

func _are_enemies(a:Dictionary,b:Dictionary) -> bool:
    return int(a["team"]) != int(b["team"])

func _find_player(id:int):
    for p in players:
        if int(p["id"]) == id: return p
    return null

func _kill_player(killer:Dictionary,victim:Dictionary) -> void:
    victim["dead"] = true
    victim["deaths"] = int(victim["deaths"]) + 1
    killer["kills"] = int(killer["kills"]) + 1
    var mid := int(victim["match_id"])
    var m:Dictionary = _matches.get(mid,{})
    m["blue"] = int(m.get("blue",0))
    m["red"] = int(m.get("red",0))
    if int(killer["team"]) == 0: m["blue"] += 1
    elif int(killer["team"]) == 1: m["red"] += 1
    _matches[mid] = m
    if not str(m["mode"]).begins_with("SHOWDOWN"):
        victim["respawn"] = 3.0

@rpc("any_peer","reliable")
func player_super() -> void:
    if not server_mode:return
    var id := multiplayer.get_remote_sender_id()
    var shooter = _find_player(id)
    if shooter == null or bool(shooter["dead"]) or float(shooter["super"]) < 100.0: return
    var mid := int(shooter["match_id"])
    shooter["super"] = 0.0
    var radius := 280.0
    var super_damage := 340.0
    for target in _players_in_match(mid):
        if int(target["id"]) == id or bool(target["dead"]): continue
        if _are_enemies(shooter,target) and shooter["pos"].distance_to(target["pos"]) <= radius:
            target["hp"] = max(0.0,float(target["hp"]) - super_damage)
            if float(target["hp"]) <= 0.0: _kill_player(shooter,target)
    super_cast.rpc(shooter["pos"],id,mid)
    _broadcast_match(mid)

@rpc("any_peer","reliable")
func player_boost() -> void:
    if not server_mode:return
    var id := multiplayer.get_remote_sender_id()
    var p = _find_player(id)
    if p == null or bool(p["dead"]) or int(p["boosts"]) <= 0: return
    p["boosts"] = int(p["boosts"]) - 1
    p["hp"] = min(MAX_HP,float(p["hp"]) + 280.0)
    p["super"] = min(100.0,float(p["super"]) + 25.0)
    _broadcast_match(int(p["match_id"]))

@rpc("any_peer","reliable")
func leave_match_rpc() -> void:
    if not server_mode:return
    var id := multiplayer.get_remote_sender_id()
    for p in players:
        if int(p["id"]) == id:
            p["match_id"] = 0
            p["ready"] = false
            p["mode"] = ""
            p["team"] = -1
    _send_roster()

func _server_tick(delta:float) -> void:
    if not server_mode:return
    var finished:Array = []
    for match_id in _matches.keys():
        var m:Dictionary = _matches[match_id]
        m["time"] = float(m.get("time",MATCH_LENGTH)) - delta
        for p in _players_in_match(int(match_id)):
            p["fire_cd"] = max(0.0,float(p.get("fire_cd",0.0))-delta)
            if bool(p["dead"]):
                if not str(m["mode"]).begins_with("SHOWDOWN"):
                    p["respawn"] = float(p["respawn"]) - delta
                    if p["respawn"] <= 0.0:
                        p["dead"] = false
                        p["hp"] = MAX_HP
                        p["super"] = 0.0
        _matches[match_id] = m
        _broadcast_match(int(match_id))
        if _match_should_end(int(match_id),m): finished.append(int(match_id))
    for match_id in finished: _finish_server_match(match_id)

func _match_should_end(mid:int,m:Dictionary)->bool:
    var mode_name:=str(m["mode"])
    var ps:=_players_in_match(mid)
    if ps.is_empty(): return true
    if mode_name == "SHOWDOWN SOLO":
        var alive:=0
        for p in ps: if not bool(p["dead"]): alive+=1
        return alive <= 1 or float(m["time"]) <= 0.0
    if mode_name == "SHOWDOWN DUO":
        var alive_teams:Dictionary={}
        for p in ps:
            if not bool(p["dead"]): alive_teams[int(p["team"])]=true
        return alive_teams.size() <= 1 or float(m["time"]) <= 0.0
    var target:=10
    if mode_name=="VOID DUEL": target=5
    elif mode_name=="DUO CLASH": target=8
    return int(m.get("blue",0))>=target or int(m.get("red",0))>=target or float(m["time"])<=0.0

func _finish_server_match(mid:int) -> void:
    if not _matches.has(mid): return
    var m:Dictionary=_matches[mid]
    var winner:=0
    if str(m["mode"]) == "SHOWDOWN SOLO":
        for p in _players_in_match(mid):
            if not bool(p["dead"]): winner=int(p["team"]); break
    elif str(m["mode"]) == "SHOWDOWN DUO":
        var alive:Dictionary={}
        for p in _players_in_match(mid):
            if not bool(p["dead"]): alive[int(p["team"])]=true
        if not alive.is_empty(): winner=int(alive.keys()[0])
    else:
        winner=0 if int(m.get("blue",0))>=int(m.get("red",0)) else 1
    match_finished.rpc(mid,winner,str(m["mode"]))
    for p in _players_in_match(mid):
        p["match_id"]=0;p["ready"]=false;p["mode"]="";p["team"]=-1
    _matches.erase(mid)
    _send_roster()

@rpc("authority","reliable")
func roster(list:Array) -> void:
    players = list
    roster_changed.emit(players)

@rpc("authority","reliable")
func match_found(wanted_mode:String,list:Array) -> void:
    players = list
    match_active = true
    mode = wanted_mode
    _set_status("MATCH FOUND • %d PLAYERS" % list.size())
    match_ready.emit(wanted_mode,players)

@rpc("authority","unreliable")
func world_state(list:Array) -> void:
    players = list
    world_updated.emit(players)
    roster_changed.emit(players)

@rpc("authority","unreliable")
func remote_shot(pos:Vector2,direction:Vector2,damage:float,player_id:int,match_id:int) -> void:
    if not server_mode:
        remote_shot_received.emit(player_id,pos,direction,damage)

@rpc("authority","unreliable")
func super_cast(pos:Vector2,player_id:int,match_id:int) -> void:
    if not server_mode:
        remote_shot_received.emit(player_id,pos,Vector2.ZERO,0.0)

@rpc("authority","reliable")
func match_finished(match_id:int,winner_team:int,finished_mode:String) -> void:
    if server_mode:return
    match_active=false
    match_ended.emit("WIN" if _local_team_for_match() == winner_team else "LOSS")

func _local_team_for_match() -> int:
    var id:=multiplayer.get_unique_id()
    for p in players:
        if int(p.get("id",-1))==id:return int(p.get("team",-1))
    return -1
