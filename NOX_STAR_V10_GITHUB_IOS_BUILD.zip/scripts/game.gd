extends Node2D

const W := 1600.0
const H := 900.0
const MATCH_TIME := 120.0
const MAX_HP := 1000.0
const FIRE_COOLDOWN := 0.42
const SUPER_MAX := 100.0
const MAX_AMMO := 3

var screen := "lobby"
var mode := "NEON RAID"
var loading := 0.0
var match_time := MATCH_TIME
var score_blue := 0
var score_red := 0
var player := Vector2(300, 450)
var hp := MAX_HP
var super_charge := 0.0
var boost_charges := 1
var trophies := 0
var coins := 500
var gems := 0
var chest := 30
var quest_progress := 0
var quest_target := 10
var fire_cd := 0.0
var ammo := MAX_AMMO
var ammo_reload := 0.0
var message := ""
var message_time := 0.0
var respawn_time := 0.0
var dead := false
var selected_noxer := "KAI"
var noxer_index := 0
var noxer_names := ["KAI", "NYX", "VOLT"]
var joystick := Vector2.ZERO
var aim := Vector2(1, 0)
var dragging_move := false
var dragging_aim := false
var touch_move_id := -1
var touch_aim_id := -1
var projectiles: Array = []
var enemies: Array = []
var allies: Array = []
var crystals: Array = []
var particles: Array = []
var walls := [Rect2(520,300,170,70),Rect2(910,530,170,70),Rect2(700,190,200,55),Rect2(690,655,220,55)]
var font: Font = ThemeDB.fallback_font
var tex_kai: Texture2D
var tex_nyx: Texture2D
var tex_volt: Texture2D
var tex_neon: Texture2D
var tex_void: Texture2D
var attack_sfx: AudioStream
var hit_sfx: AudioStream
var super_sfx: AudioStream
var victory_sfx: AudioStream

func _ready() -> void:
    tex_kai = load("res://assets/characters_png/kai_sheet.png")
    tex_nyx = load("res://assets/characters_png/nyx_sheet.png")
    tex_volt = load("res://assets/characters_png/volt_sheet.png")
    tex_neon = load("res://assets/maps_png/neon_raid.png")
    tex_void = load("res://assets/maps_png/void_duel.png")
    attack_sfx = load("res://assets/audio/attack.wav")
    hit_sfx = load("res://assets/audio/hit.wav")
    super_sfx = load("res://assets/audio/super.wav")
    victory_sfx = load("res://assets/audio/victory.wav")
    trophies = int(ProjectSettings.get_setting("nox/trophies", 0))
    coins = int(ProjectSettings.get_setting("nox/coins", 500))
    gems = int(ProjectSettings.get_setting("nox/gems", 0))
    chest = int(ProjectSettings.get_setting("nox/chest", 30))
    quest_progress = int(ProjectSettings.get_setting("nox/quest", 0))
    queue_redraw()

func _process(delta: float) -> void:
    if message_time > 0: message_time -= delta
    if screen == "loading":
        loading += delta
        if loading >= 1.8:
            screen = "battle"
            begin_match()
    elif screen == "battle":
        update_battle(delta)
    queue_redraw()

func _input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed:
        if event.keycode == KEY_ESCAPE:
            screen = "lobby"
        elif event.keycode == KEY_SPACE: fire()
        elif event.keycode == KEY_Q: use_super()
        elif event.keycode == KEY_E: use_boost()
        elif event.keycode == KEY_TAB and screen == "lobby": screen = "noxers"
    if event is InputEventScreenTouch:
        if event.pressed: handle_touch_down(event.index, event.position)
        else: handle_touch_up(event.index)
    if event is InputEventScreenDrag: handle_touch_drag(event.index, event.position)

func handle_touch_down(id: int, p: Vector2) -> void:
    if screen == "lobby":
        if Rect2(650,700,300,90).has_point(p): screen = "modes"
        elif Rect2(30,760,260,90).has_point(p): screen = "road"
        elif Rect2(320,760,260,90).has_point(p): screen = "noxers"
        elif Rect2(990,760,260,90).has_point(p): screen = "shop"
        elif Rect2(1260,760,300,90).has_point(p): screen = "quests"
    elif screen == "modes":
        if Rect2(180,300,360,250).has_point(p): start_mode("NEON RAID")
        elif Rect2(620,300,360,250).has_point(p): start_mode("VOID DUEL")
        elif Rect2(1060,300,360,250).has_point(p): start_mode("TRAINING")
        elif Rect2(30,25,180,65).has_point(p): screen = "lobby"
    elif screen == "road":
        if Rect2(30,25,180,65).has_point(p): screen = "lobby"
        elif Rect2(620,690,360,90).has_point(p) and chest >= 100: open_chest()
    elif screen == "noxers":
        if Rect2(40,760,180,70).has_point(p): screen = "lobby"
        elif Rect2(260,260,300,420).has_point(p): choose_noxer(0)
        elif Rect2(650,260,300,420).has_point(p): choose_noxer(1)
        elif Rect2(1040,260,300,420).has_point(p): choose_noxer(2)
    elif screen == "shop":
        if Rect2(40,760,180,70).has_point(p): screen = "lobby"
        elif Rect2(580,300,440,190).has_point(p) and coins >= 120:
            coins -= 120; gems += 1; save_progress(); show_message("BOOST GEM +1")
    elif screen == "quests":
        if Rect2(40,760,180,70).has_point(p): screen = "lobby"
        elif Rect2(600,610,400,90).has_point(p) and quest_progress >= quest_target:
            quest_progress = 0; coins += 180; gems += 2; save_progress(); show_message("QUEST REWARD!")
    elif screen == "result":
        if Rect2(620,690,360,90).has_point(p): screen = "lobby"
    elif screen == "battle":
        if p.x < W*0.42 and p.y > H*0.50:
            dragging_move = true; touch_move_id = id
            joystick = ((p-Vector2(160,690))/105.0).limit_length(1.0)
        elif p.x > W*0.58 and p.y > H*0.48:
            dragging_aim = true; touch_aim_id = id
            var a := p-player
            if a.length() > 10: aim = a.normalized()
        elif Rect2(W-250,H-190,150,150).has_point(p): fire()
        elif Rect2(W-420,H-165,120,120).has_point(p): use_super()
        elif Rect2(W-420,H-315,90,90).has_point(p): use_boost()

func handle_touch_drag(id:int,p:Vector2)->void:
    if screen != "battle": return
    if id == touch_move_id: joystick=((p-Vector2(160,690))/105.0).limit_length(1.0)
    elif id == touch_aim_id:
        var a:=p-player
        if a.length()>10: aim=a.normalized()

func handle_touch_up(id:int)->void:
    if id==touch_move_id: dragging_move=false; touch_move_id=-1; joystick=Vector2.ZERO
    if id==touch_aim_id: dragging_aim=false; touch_aim_id=-1

func start_mode(m:String)->void:
    mode=m; loading=0; screen="loading"

func choose_noxer(i:int)->void:
    noxer_index=i; selected_noxer=noxer_names[i]; show_message(selected_noxer+" SELECTED")

func begin_match()->void:
    match_time=MATCH_TIME; score_blue=0; score_red=0; hp=MAX_HP; super_charge=0; boost_charges=1; ammo=MAX_AMMO; fire_cd=0; ammo_reload=0
    dead=false; projectiles.clear(); enemies.clear(); allies.clear(); crystals.clear(); particles.clear()
    player=Vector2(300,450)
    for p in [Vector2(790,420),Vector2(820,470),Vector2(780,520),Vector2(850,500),Vector2(760,465),Vector2(805,445)]: crystals.append({"p":p,"taken":false,"pulse":randf()*6.0})
    enemies=[
        unit(Vector2(1180,330),"NYX",900),unit(Vector2(1250,450),"VOLT",1050),unit(Vector2(1160,590),"KAI",1000)
    ]
    allies=[unit(Vector2(260,320),"VOLT",900),unit(Vector2(260,580),"NYX",900)]
    show_message(mode+" • 3V3")

func unit(pos:Vector2,n:String,h:float)->Dictionary:
    return {"p":pos,"hp":h,"max":h,"cool":randf_range(.1,.8),"respawn":0.0,"dead":false,"name":n,"super":0.0}

func update_battle(delta:float)->void:
    match_time-=delta; fire_cd=max(0.0,fire_cd-delta)
    if ammo<MAX_AMMO:
        ammo_reload+=delta
        if ammo_reload>=0.8: ammo+=1; ammo_reload=0
    for p in particles.duplicate():
        p["life"]-=delta; p["p"]+=p["v"]*delta
        if p["life"]<=0: particles.erase(p)
    if dead:
        respawn_time-=delta
        if respawn_time<=0: dead=false; hp=MAX_HP; player=Vector2(300,450); ammo=MAX_AMMO
        return
    var move_vec:=joystick
    if Input.is_key_pressed(KEY_A): move_vec.x-=1
    if Input.is_key_pressed(KEY_D): move_vec.x+=1
    if Input.is_key_pressed(KEY_W): move_vec.y-=1
    if Input.is_key_pressed(KEY_S): move_vec.y+=1
    move_vec=move_vec.limit_length(1.0)
    if move_vec.length()>0.05: player=move_with_walls(player,move_vec*360.0*delta)
    for c in crystals:
        if not c["taken"] and player.distance_to(c["p"])<55:
            c["taken"]=true; score_blue+=1; super_charge=min(SUPER_MAX,super_charge+8); quest_progress=min(quest_target,quest_progress+1); spawn_fx(c["p"],Color("#65eaff"),12)
    ai_team(enemies,true,delta); ai_team(allies,false,delta); update_projectiles(delta)
    if mode=="NEON RAID" and score_blue>=10: end_match(true)
    elif mode=="VOID DUEL" and (score_blue>=6 or score_red>=6): end_match(score_blue>=score_red)
    elif match_time<=0: end_match(score_blue>=score_red)

func move_with_walls(pos:Vector2,delta_pos:Vector2)->Vector2:
    var np=clamp_to_arena(pos+Vector2(delta_pos.x,0))
    for r in walls:
        if r.grow(12).has_point(np): np.x=pos.x
    np=clamp_to_arena(Vector2(np.x,pos.y+delta_pos.y))
    for r in walls:
        if r.grow(12).has_point(np): np.y=pos.y
    return np

func ai_team(team:Array,hostile:bool,delta:float)->void:
    for u in team:
        if u["dead"]:
            u["respawn"]-=delta
            if u["respawn"]<=0:
                u["dead"]=false; u["hp"]=u["max"]; u["p"]=Vector2(1180,350) if hostile else Vector2(280,450)
            continue
        var target:=player
        if not hostile:
            var best=999999.0
            for e in enemies:
                if not e["dead"] and e["p"].distance_to(u["p"])<best: best=e["p"].distance_to(u["p"]); target=e["p"]
        var d:Vector2=target-u["p"]
        if d.length()>260: u["p"]=move_with_walls(u["p"],d.normalized()*105.0*delta)
        elif d.length()<125: u["p"]=move_with_walls(u["p"],-d.normalized()*50.0*delta)
        u["cool"]-=delta
        if u["cool"]<=0 and d.length()<720:
            u["cool"]=.9 if u["name"]=="VOLT" else 1.05
            var damage=110.0 if u["name"]!="KAI" else 130.0
            projectiles.append({"p":u["p"],"v":d.normalized()*560.0,"team":"red" if hostile else "blue","damage":damage,"life":1.7,"owner":u})

func update_projectiles(delta:float)->void:
    for b in projectiles.duplicate():
        b["p"]+=b["v"]*delta; b["life"]-=delta
        var remove:=b["life"]<=0 or b["p"].x<20 or b["p"].x>W-20 or b["p"].y<100 or b["p"].y>H-30
        for r in walls:
            if r.has_point(b["p"]): remove=true
        if not remove and b["team"]=="red" and not dead and b["p"].distance_to(player)<42:
            hp-=b["damage"]; super_charge=min(SUPER_MAX,super_charge+10); spawn_fx(player,Color("#ff5f83"),14); remove=true
            if hp<=0: die_player()
        elif not remove and b["team"]=="blue":
            for e in enemies:
                if not e["dead"] and b["p"].distance_to(e["p"])<45:
                    e["hp"]-=b["damage"]; super_charge=min(SUPER_MAX,super_charge+16); spawn_fx(e["p"],Color("#ffe16b"),12); remove=true
                    if e["hp"]<=0: kill_enemy(e)
                    break
        if remove: projectiles.erase(b)

func kill_enemy(e:Dictionary)->void:
    e["dead"]=true; e["respawn"]=4.0; score_blue+=1; quest_progress=min(quest_target,quest_progress+1); spawn_fx(e["p"],Color("#ff5f83"),32)

func fire()->void:
    if screen!="battle" or dead or fire_cd>0 or ammo<=0: return
    fire_cd=FIRE_COOLDOWN; ammo-=1; ammo_reload=0
    var direction:=aim.normalized() if aim.length()>0.1 else Vector2(1,0)
    var damage:=140.0
    if selected_noxer=="VOLT": damage=125.0
    elif selected_noxer=="NYX": damage=155.0
    projectiles.append({"p":player+direction*55,"v":direction*900,"team":"blue","damage":damage,"life":1.0,"owner":null})
    spawn_fx(player+direction*55,Color("#ffe16b"),5)

func use_super()->void:
    if screen!="battle" or dead or super_charge<SUPER_MAX: show_message("SUPER NOT READY"); return
    super_charge=0; spawn_fx(player,Color("#8060f4"),70)
    var radius:=260.0
    if selected_noxer=="NYX": radius=310.0
    for e in enemies:
        if not e["dead"] and e["p"].distance_to(player)<radius:
            e["hp"]-=420 if selected_noxer=="KAI" else 340
            if e["hp"]<=0: kill_enemy(e)
    if selected_noxer=="VOLT": hp=min(MAX_HP,hp+220)
    player=clamp_to_arena(player+aim.normalized()*90)
    show_message("NOVA SUPER!")

func use_boost()->void:
    if screen!="battle" or boost_charges<=0: show_message("NO BOOST GEM"); return
    boost_charges-=1; hp=min(MAX_HP,hp+280); super_charge=min(SUPER_MAX,super_charge+25); spawn_fx(player,Color("#41dfd0"),32); show_message("BOOST GEM +280 HP")

func die_player()->void:
    dead=true; respawn_time=3.5; score_red+=1; spawn_fx(player,Color("#ff5f83"),45); show_message("RESPAWNING...")

func end_match(win:bool)->void:
    if screen!="battle": return
    screen="result"
    if win:
        trophies+=8; coins+=35; chest=min(100,chest+15); show_message("VICTORY")
    else:
        trophies=max(0,trophies-2); coins+=10; chest=min(100,chest+4); show_message("DEFEAT")
    save_progress()

func open_chest()->void:
    chest=0; coins+=250; gems+=3; show_message("STAR CASE OPENED • +3 BOOST GEMS"); save_progress()

func save_progress()->void:
    ProjectSettings.set_setting("nox/trophies",trophies); ProjectSettings.set_setting("nox/coins",coins); ProjectSettings.set_setting("nox/gems",gems); ProjectSettings.set_setting("nox/chest",chest); ProjectSettings.set_setting("nox/quest",quest_progress)

func show_message(s:String)->void: message=s; message_time=1.2
func clamp_to_arena(p:Vector2)->Vector2: return Vector2(clamp(p.x,70.0,W-70.0),clamp(p.y,135.0,H-80.0))
func spawn_fx(p:Vector2,color:Color,count:int)->void:
    for i in range(count):
        var a=randf()*TAU; var speed=randf_range(50,230); particles.append({"p":p,"v":Vector2(cos(a),sin(a))*speed,"life":randf_range(.25,.65),"c":color})

func _draw()->void:
    match screen:
        "lobby": draw_lobby()
        "modes": draw_modes()
        "road": draw_road()
        "noxers": draw_noxers()
        "shop": draw_shop()
        "quests": draw_quests()
        "loading": draw_loading()
        "battle": draw_battle()
        "result": draw_result()

func draw_lobby()->void:
    draw_rect(Rect2(0,0,W,H),Color("#080d20")); draw_texture_rect(tex_neon,Rect2(0,0,W,H),false); draw_rect(Rect2(0,0,W,H),Color("#07102dcc")); top_bar()
    panel(Rect2(45,160,310,210),"NEON RAID","3v3 • CRYSTAL CONTROL")
    panel(Rect2(1245,160,310,210),"VOID DUEL","1v1 • LAST STAR")
    draw_noxer(tex_for_name(selected_noxer),Vector2(800,445),.9)
    text(selected_noxer+" • NOXER",Vector2(650,590),34)
    text("SELECTED NOXER • SUPER + BOOST GEM",Vector2(610,625),18,Color("#b6c4e8"))
    button(Rect2(650,700,300,90),"PLAY",Color("#ffb72e"))
    button(Rect2(30,760,260,90),"TROPHY ROAD",Color("#182342")); button(Rect2(320,760,260,90),"NOXERS",Color("#182342")); button(Rect2(990,760,260,90),"SHOP",Color("#182342")); button(Rect2(1260,760,300,90),"QUESTS",Color("#182342"))
    panel(Rect2(45,500,310,130),"STAR CASE","🎁 %d/100 • 3 Boost Gems inside" % chest)

func tex_for_name(n:String)->Texture2D:
    if n=="NYX": return tex_nyx
    if n=="VOLT": return tex_volt
    return tex_kai

func draw_modes()->void:
    draw_rect(Rect2(0,0,W,H),Color("#0a1024")); top_bar(); button(Rect2(30,25,180,65),"← BACK",Color("#182342")); text("SELECT EVENT",Vector2(70,150),48)
    panel(Rect2(180,300,360,250),"NEON RAID","3v3 • Collect crystals\n🏆 +8")
    panel(Rect2(620,300,360,250),"VOID DUEL","1v1 • First to 6\n🏆 +8")
    panel(Rect2(1060,300,360,250),"TRAINING","Aim • movement • Super\nNo trophy loss")

func draw_road()->void:
    draw_rect(Rect2(0,0,W,H),Color("#091025")); top_bar(); button(Rect2(30,25,180,65),"← BACK",Color("#182342")); text("TROPHY ROAD",Vector2(80,165),50)
    for i in range(7):
        var x=130+i*225; var got=trophies>=i*100; draw_circle(Vector2(x,410),54,Color("#ffd04a") if got else Color("#283554")); text(str(i*100),Vector2(x-25,490),20)
        if i<6: draw_line(Vector2(x+55,410),Vector2(x+170,410),Color("#405684"),8)
    text("STAR CASE",Vector2(680,610),32); text("%d / 100" % chest,Vector2(720,660),28,Color("#65eaff")); button(Rect2(620,690,360,90),"OPEN CASE" if chest>=100 else "CASE LOCKED",Color("#ffb72e") if chest>=100 else Color("#273452"))

func draw_noxers()->void:
    draw_rect(Rect2(0,0,W,H),Color("#080d20")); top_bar(); button(Rect2(40,760,180,70),"← BACK",Color("#182342")); text("NOXERS",Vector2(70,150),50); text("Pick your fighter. Every Noxer has a different Super.",Vector2(70,190),20,Color("#aab8df"))
    noxer_card(Rect2(260,260,300,420),"KAI",tex_kai,"Balanced","NOVA BURST","140 dmg")
    noxer_card(Rect2(650,260,300,420),"NYX",tex_nyx,"Heavy control","VOID PULSE","155 dmg")
    noxer_card(Rect2(1040,260,300,420),"VOLT",tex_volt,"Fast support","OVERCHARGE","125 dmg")

func noxer_card(r:Rect2,n:String,tex:Texture2D,role:String,sp:String,stat:String)->void:
    draw_rect(r,Color("#111b39e8")); draw_rect(r,Color("#65eaff") if selected_noxer==n else Color("#41598d"),false,4); draw_brawler_frame(tex,r.position+Vector2(150,145),int(Time.get_ticks_msec()/120)%8,.48); text(n,r.position+Vector2(25,260),32); text(role,r.position+Vector2(25,300),18,Color("#b4c1e3")); text("SUPER  "+sp,r.position+Vector2(25,350),18); text("ATTACK  "+stat,r.position+Vector2(25,385),18,Color("#ffe16b")); text("BOOST GEM: +280 HP",r.position+Vector2(25,420),16,Color("#65eaff"))

func draw_shop()->void:
    draw_rect(Rect2(0,0,W,H),Color("#091025")); top_bar(); button(Rect2(40,760,180,70),"← BACK",Color("#182342")); text("STAR SHOP",Vector2(70,150),50); text("Spend coins on real in-game resources.",Vector2(70,190),20,Color("#aab8df"))
    panel(Rect2(280,300,440,190),"BOOST GEM ×1","120 coins • usable in battle"); button(Rect2(580,520,440,80),"BUY • 120 COINS",Color("#ffb72e")); panel(Rect2(850,300,440,190),"UPGRADE CORE","Coming in next content pass\nNoxer power progression")

func draw_quests()->void:
    draw_rect(Rect2(0,0,W,H),Color("#091025")); top_bar(); button(Rect2(40,760,180,70),"← BACK",Color("#182342")); text("QUESTS",Vector2(70,150),50); panel(Rect2(300,300,1000,230),"CRYSTAL RUNNER","Collect crystals or score eliminations in battle."); text("PROGRESS",Vector2(360,590),24); draw_rect(Rect2(360,625,880,26),Color("#17213a")); draw_rect(Rect2(364,629,872*float(quest_progress)/quest_target,18),Color("#65eaff")); text("%d / %d" % [quest_progress,quest_target],Vector2(760,690),25); button(Rect2(600,610,400,90),"CLAIM +180 COINS +2 GEMS",Color("#ffb72e") if quest_progress>=quest_target else Color("#273452"))

func draw_loading()->void:
    draw_rect(Rect2(0,0,W,H),Color("#070b18")); text("NOX STAR",Vector2(650,330),64); text("LOADING %s" % mode,Vector2(620,420),25,Color("#b6c4e8")); draw_rect(Rect2(450,520,700,28),Color("#18233e")); draw_rect(Rect2(450,520,700*min(1.0,loading/1.8),28),Color("#55dfff")); text("Preparing arena • syncing Noxers • loading effects",Vector2(510,590),18,Color("#8fa3cf"))

func draw_battle()->void:
    var map_tex:=tex_neon if mode!="VOID DUEL" else tex_void; draw_texture_rect(map_tex,Rect2(0,0,W,H),false); draw_rect(Rect2(0,0,W,H),Color("#06101a55")); top_bar()
    for r in walls: draw_rect(r,Color("#0c1730dd")); draw_rect(r,Color("#5a79aa"),false,4)
    health_bar(Vector2(35,105),hp,MAX_HP,selected_noxer,Color("#55e58b")); text("AMMO %d / %d" % [ammo,MAX_AMMO],Vector2(350,145),18,Color("#ffe16b")); text("ENEMIES %d" % alive_count(enemies),Vector2(1350,145),18,Color("#ff91a9")); text("%02d:%02d" % [int(match_time)/60,int(match_time)%60],Vector2(750,118),30); text("%d  —  %d" % [score_blue,score_red],Vector2(745,155),24,Color("#ffe16b"))
    for c in crystals:
        if not c["taken"]:
            var q=c["p"]; var pulse=4.0+sin(Time.get_ticks_msec()/180.0+c["pulse"])*5.0; var pts=PackedVector2Array([q+Vector2(0,-24-pulse),q+Vector2(24,0),q+Vector2(0,24+pulse),q+Vector2(-24,0)]); draw_colored_polygon(pts,Color("#65eaff")); draw_polyline(pts,Color.WHITE,4)
    if not dead: draw_brawler_frame(tex_for_name(selected_noxer),player,int(Time.get_ticks_msec()/110)%8,.72)
    for e in enemies:
        if not e["dead"]: draw_brawler_frame(tex_for_name(e["name"]),e["p"],int(Time.get_ticks_msec()/140)%8,.60); small_hp(e["p"]+Vector2(-50,-95),e["hp"],e["max"],Color("#ff5f83"))
    for a in allies:
        if not a["dead"]: draw_brawler_frame(tex_for_name(a["name"]),a["p"],int(Time.get_ticks_msec()/150)%8,.52); small_hp(a["p"]+Vector2(-45,-85),a["hp"],a["max"],Color("#55e58b"))
    for b in projectiles: draw_circle(b["p"],9,Color("#ffe16b") if b["team"]=="blue" else Color("#ff668a"))
    for p in particles: draw_circle(p["p"],max(2.0,9.0*p["life"]),p["c"])
    controls()

func alive_count(a:Array)->int:
    var n=0
    for x in a: if not x["dead"]: n+=1
    return n

func controls()->void:
    draw_circle(Vector2(160,690),105,Color("#071329b8")); draw_circle(Vector2(160+joystick.x*42,690+joystick.y*42),34,Color("#a7b9d4cc")); draw_circle(Vector2(W-125,H-120),82,Color("#ff7b3b")); text("ATTACK",Vector2(W-176,H-111),20,Color("#241000")); var sc=super_charge/SUPER_MAX; draw_circle(Vector2(W-360,H-105),58,Color("#8060f4") if sc>=1 else Color("#4a3f76")); text("SUPER",Vector2(W-399,H-99),16); draw_arc(Vector2(W-360,H-105),68,-PI/2,-PI/2+TAU*sc,false,6,Color("#d8d0ff")); draw_circle(Vector2(W-375,H-270),45,Color("#41dfd0") if boost_charges>0 else Color("#285e60")); text("BOOST",Vector2(W-401,H-265),13,Color("#062326"));
    if dead: draw_rect(Rect2(0,0,W,H),Color("#05071399")); text("RESPAWNING %0.1f" % respawn_time,Vector2(675,430),34,Color("#ff91a9"))
    if message_time>0: text(message,Vector2(650,195),28,Color("#ffe16b"))

func draw_result()->void:
    draw_rect(Rect2(0,0,W,H),Color("#091025")); top_bar(); var win:=score_blue>=score_red; text("VICTORY" if win else "DEFEAT",Vector2(625,300),72,Color("#ffd04a") if win else Color("#ff6688")); text("+8 TROPHIES • +35 COINS" if win else "-2 TROPHIES • +10 COINS",Vector2(610,540),25); text("SCORE  %d — %d" % [score_blue,score_red],Vector2(705,590),25); text("STAR CASE %d / 100" % chest,Vector2(700,630),20,Color("#65eaff")); button(Rect2(620,690,360,90),"CONTINUE",Color("#ffb72e"))

func top_bar()->void:
    draw_rect(Rect2(0,0,W,92),Color("#060a18e8")); text("NOX STAR",Vector2(35,59),38); text("🏆 %d     🪙 %d     💎 %d" % [trophies,coins,gems],Vector2(1120,56),22)
func panel(r:Rect2,title:String,sub:String)->void:
    draw_rect(r,Color("#111b39e8")); draw_rect(r,Color("#41598d"),false,4); text(title,r.position+Vector2(18,48),28); text(sub,r.position+Vector2(18,84),17,Color("#b4c1e3"))
func button(r:Rect2,label:String,c:Color)->void:
    draw_rect(r,c); draw_rect(r,Color("#ffe69b"),false,4); text(label,r.position+Vector2(0,55),28,Color("#241400"),r.size.x,HORIZONTAL_ALIGNMENT_CENTER)
func text(s:String,p:Vector2,size:int,c:=Color.WHITE,width:float=-1,align:=HORIZONTAL_ALIGNMENT_LEFT)->void: draw_string(font,p,s,align,width,size,c)
func health_bar(p:Vector2,h:float,m:float,n:String,c:Color)->void:
    text(n,p,20); draw_rect(Rect2(p+Vector2(0,25),Vector2(280,20)),Color("#111827")); draw_rect(Rect2(p+Vector2(3,28),Vector2(274*clamp(h/m,0,1),14)),c)
func small_hp(p:Vector2,h:float,m:float,c:Color)->void:
    draw_rect(Rect2(p,Vector2(100,9)),Color("#111827")); draw_rect(Rect2(p+Vector2(2,2),Vector2(96*clamp(h/m,0,1),5)),c)
func draw_noxer(tex:Texture2D,p:Vector2,scale:float)->void: draw_brawler_frame(tex,p,int(Time.get_ticks_msec()/120)%8,scale)
func draw_brawler_frame(tex:Texture2D,p:Vector2,frame:int,scale:float)->void:
    if tex==null: return
    var src:=Rect2((frame%8)*512,0,512,512); var dst:=Rect2(p-Vector2(190,190)*scale,Vector2(380,380)*scale); draw_texture_rect_region(tex,dst,src)
