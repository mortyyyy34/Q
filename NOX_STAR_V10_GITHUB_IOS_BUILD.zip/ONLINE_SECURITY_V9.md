# NOX STAR V9 — Online Security

## Authority
The dedicated server owns HP, damage, fire cooldown, Super, Boost charges, kills, deaths, score, timer and match results.

## NOX GUARD
Server-side checks include:
- movement speed / teleport anomaly detection;
- fire-rate validation;
- requested-damage bounds;
- illegal Super / Boost attempts;
- strike accumulation with decay;
- automatic disconnect after repeated violations.

A lag spike should not immediately ban a player: the system uses strikes and a time window.

## Account layer
`NoxAccountStore` is a development persistence layer. Production deployment should replace the JSON store with a real authenticated database/service and signed session tokens.

## Party layer
`NoxPartyService` provides server-side party ownership, invitations and leave/owner transfer. It is intentionally separate from gameplay simulation.
